package com.mycompany.contactgui;
public class ContactGUI 
{
    public static void main(String[] args) 
    {
        ContactEditor ce=new ContactEditor();
        ce.show();
    }
}
